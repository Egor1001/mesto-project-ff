// index.js
import './pages/index.css';
import { openModal, closeModal } from './components/modal.js';
import { createCard, handleDeleteCard, handleLikeCard } from './components/card.js';
import { initialCards } from './components/cards';

const placesList = document.querySelector('.places__list');
const profileEditButton = document.querySelector('.profile__edit-button');
const profileAddButton = document.querySelector('.profile__add-button');
const popupEdit = document.querySelector('.popup_type_edit');
const popupImage = document.querySelector('.popup_type_image');
const imageElement = popupImage.querySelector('.popup__image');
const captionElement = popupImage.querySelector('.popup__caption');
const popupNewCard = document.querySelector('.popup_type_new-card');

const profileTitle = document.querySelector('.profile__title');
const profileDescription = document.querySelector('.profile__description');
// Формы
const formEdit = document.forms['edit-profile'];
const formAdd = document.forms['new-place'];
const nameInput = formEdit.elements.name;
const jobInput = formEdit.elements.description;

// Инициализация карточек
initialCards.forEach(item => {
  const card = createCard(
    item,
    handleDeleteCard,
    handleLikeCard,
    handleImageClick
  );
  placesList.append(card);
});

// Обработчики модальных окон
profileEditButton.addEventListener('click', () => {
  nameInput.value = profileTitle.textContent;
  jobInput.value = profileDescription.textContent;
  openModal(popupEdit);
});

profileAddButton.addEventListener('click', () => openModal(popupNewCard));

// Обработка формы редактирования профиля
formEdit.addEventListener('submit', (evt) => {
  evt.preventDefault();
  document.querySelector('.profile__title').textContent = formEdit.elements.name.value;
  document.querySelector('.profile__description').textContent = formEdit.elements.description.value;
  closeModal(popupEdit);
});

// Обработка формы добавления карточки
formAdd.addEventListener('submit', (evt) => {
  evt.preventDefault();
  const newCard = {
    name: formAdd.elements['place-name'].value,
    link: formAdd.elements.link.value
  };
  
  placesList.prepend(createCard(
    newCard,
    handleDeleteCard,
    handleLikeCard,
    handleImageClick
  ));
  
  formAdd.reset();
  closeModal(popupNewCard);
});

// Обработчик открытия изображения
function handleImageClick(cardData) {
  imageElement.src = cardData.link;
  imageElement.alt = cardData.name;
  captionElement.textContent = cardData.name;
  
  openModal(popupImage);
}

// Закрытие попапов
document.querySelectorAll('.popup__close').forEach(button => {
  button.addEventListener('click', () => {
    closeModal(button.closest('.popup'));
  });
});