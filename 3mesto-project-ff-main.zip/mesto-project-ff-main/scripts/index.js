const cardTemplate = document.querySelector('#card-template').content;
const placesList = document.querySelector('.places__list');

// Функция удаления карточки
function deleteCard(deleteButton) {
    deleteButton.closest('.card').remove();
}

// Функция для обработки клика по лайку
function likeCard(cardElement) {
    cardElement.querySelector('.card__like-button').classList.toggle('is-liked');
}

// Функция для обработки клика по изображению
function handleImageClick(cardData) {
    const popup = document.querySelector('.popup_type_image');
    const popupImage = popup.querySelector('.popup__image');
    const popupCaption = popup.querySelector('.popup__caption');

    popupImage.src = cardData.link;
    popupImage.alt = cardData.name;
    popupCaption.textContent = cardData.name;

    popup.classList.add('popup_opened');
}

function createCard(item, { deleteCard, likeCard, handleImageClick }) {
    const cardElement = cardTemplate.cloneNode(true);
    const cardImage = cardElement.querySelector('.card__image');
    const cardTitle = cardElement.querySelector('.card__title');
    const cardLikeButton = cardElement.querySelector('.card__like-button');
    const cardDeleteButton = cardElement.querySelector('.card__delete-button');

    cardImage.src = item.link;
    cardImage.alt = item.name;
    cardTitle.textContent = item.name;

    cardDeleteButton.addEventListener('click', (evt) => {
        deleteCard(evt.target);
    });

    cardLikeButton.addEventListener('click', () => {
        likeCard(cardElement)
    });

    cardImage.addEventListener('click', () => handleImageClick(item));
    return cardElement;
}

function renderCards (cards) {
    cards.forEach(card => {
        const cardElement = createCard(card, {
            deleteCard: deleteCard,
            likeCard: likeCard,
            handleImageClick: handleImageClick
        });
        placesList.appendChild(cardElement);
    });
}

renderCards(initialCards);