// @todo: Темплейт карточки
const cardTemplate = document.querySelector('#card-template').content;
// @todo: DOM узлы
const places__list = document.querySelector('.places__list');
// @todo: Функция создания карточки
function createCard(item, { deleteCard, likeCard, handleImageClick }) {
  
  const cardElement = cardTemplate.cloneNode(true); /* Клонирование шаблона */

  const cardImage = cardElement.querySelector('.card__image');
  const cardTitle = cardElement.querySelector('.card__title');
  const cardLike = cardElement.querySelector('.card__like-button');
  const cardDelete = cardElement.querySelector('.card__delete-button');

  cardImage.src = cardData.link;
  cardImage.alt = cardData.name;
  cardTitle.textContent = cardData.name;

  cardDelete.addEventListener('click', () => {
    removeCard(cardElement);
  });
  
  cardLikeButton.addEventListener('click', () => {
    cardLikeButton.classList.toggle('is-liked');
  });
  
  cardImage.addEventListener('click', () => handleImageClick(cardData));
  
  return cardElement;
}
  // @todo: Функция удаления карточки
function removeCard(cardElement) {
  cardElement.remove(cardElement);
}

function handleImageClick(cardData) {
  console.log('clicked', cardData);
}
  // @todo: Вывести карточки на страницу
  function renderCards (cards) {
    cards.forEach(card => {
      const cardElement = createCard(card);
      placesList.append(cardElement);
    });
  }
  renderCards(initialCards);