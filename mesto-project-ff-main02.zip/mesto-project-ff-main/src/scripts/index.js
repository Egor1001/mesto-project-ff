import { createCard, deleteCard, likeCard } from './components/card.js';
import { openModal, closeModal } from './components/modal.js';

import { initialCards } from './cards.js';

const placesList = document.querySelector('.places__list');
const profileEditButton = document.querySelector('.profile__edit-button');
const addCardButton = document.querySelector('.profile__add-button');

// Попапы
const editProfilePopup = document.querySelector('.popup_type_edit');
const addCardPopup = document.querySelector('.popup_type_new-card');
const imagePopup = document.querySelector('.popup_type_image');

// Формы
const editForm = document.forms['edit-profile'];
const addCardForm = document.forms['new-place'];

// Обработчики открытия попапов
profileEditButton.addEventListener('click', () => {
    openModal(editProfilePopup);
    fillProfileForm();
});

addCardButton.addEventListener('click', () => {
    openModal(addCardPopup);
});

// Закрытие попапов
document.querySelectorAll('.popup__close').forEach(button => {
    button.addEventListener('click', () => closeModal(button.closest('.popup')));
});

// Редактирование профиля
function fillProfileForm() {
    const name = document.querySelector('.profile__title').textContent;
    const job = document.querySelector('.profile__description').textContent;
    editForm.elements.name.value = name;
    editForm.elements.description.value = job;
}

editForm.addEventListener('submit', (evt) => {
    evt.preventDefault();
    document.querySelector('.profile__title').textContent = editForm.elements.name.value;
    document.querySelector('.profile__description').textContent = editForm.elements.description.value;
    closeModal(editProfilePopup);
});

// Добавление карточки
addCardForm.addEventListener('submit', (evt) => {
    evt.preventDefault();
    const newCard = {
        name: addCardForm.elements['place-name'].value,
        link: addCardForm.elements.link.value
    };
    placesList.prepend(createCard(newCard, { handleDeleteCard: deleteCard, handleLikeCard: likeCard, handleImageClick }));
    addCardForm.reset();
    closeModal(addCardPopup);
});

// Рендер начальных карточек
initialCards.forEach(card => {
    placesList.append(createCard(card, { 
        handleDeleteCard: deleteCard, 
        handleLikeCard: (evt) => likeCard(evt), 
        handleImageClick: (item) => {
            const imagePopupContent = imagePopup.querySelector('.popup__image');
            imagePopupContent.src = item.link;
            imagePopupContent.alt = item.name;
            imagePopup.querySelector('.popup__caption').textContent = item.name;
            openModal(imagePopup);
        }
    }));
});