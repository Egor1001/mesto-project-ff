export function createCard(item, { handleDeleteCard, handleLikeCard, handleImageClick }) {
    const cardTemplate = document.querySelector('#card-template').content;
    const cardElement = cardTemplate.cloneNode(true);
    
    cardDeleteButton.addEventListener('click', handleDeleteCard);
    cardLikeButton.addEventListener('click', handleLikeCard);
    cardImage.addEventListener('click', () => handleImageClick(item));
    
    return cardElement;
}

export function deleteCard(evt) {
    evt.target.closest('.card').remove();
}

export function likeCard(evt) {
    evt.target.classList.toggle('card__like-button_is-active');
}