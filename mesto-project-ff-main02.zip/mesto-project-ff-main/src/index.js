import './pages/index.css'; // добавьте импорт главного файла стилей

const numbers = [2, 3, 5];

// Стрелочная функция. Не запнётся ли на ней Internet Explorer?
const doubledNumbers = numbers.map(number => number * 2);

console.log(doubledNumbers); // 4, 6, 10
// теперь картинки можно импортировать,
// вебпак добавит в переменные правильные пути
const avatarImage = new URL('./images/avatar.jpg', import.meta.url);
const churchImage = new URL('./images/church.jpg', import.meta.url);
const fieldImage = new URL('./images/field.jpg', import.meta.url)
const forestImage = new URL('./images/forest.jpg', import.meta.url);

const whoIsTheGoat = [
  // меняем исходные пути на переменные
  { name: 'avatar', link: avatarImage },
  { name: 'church', link: churchImage },
  { name: 'field', link: fieldImage },
  { name: 'forest', link: forestImage },
];