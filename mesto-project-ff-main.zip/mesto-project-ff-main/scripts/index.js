// @todo: Темплейт карточки
const cardTemplate = document.querySelector('#card-template').content;
// @todo: DOM узлы
const placesList = document.querySelector('.places__list');
// @todo: Функция создания карточки
function createCard(cardData) {
    const cardElement = cardTemplate.cloneNode(true);
    const cardImage = cardElement.querySelector('.card__image');
    const cardTitle = cardElement.querySelector('.card__title');
    const cardLikeButton = cardElement.querySelector('.card__like-button');
    const cardDeleteButton = cardElement.querySelector('.card__delete-button');
  
    cardImage.src = cardData.link;
    cardImage.alt = cardData.name;
    cardTitle.textContent = cardData.name;
  
    cardLikeButton.addEventListener('click', () => {
      cardLikeButton.classList.toggle('is-liked');
    });
  
    cardDeleteButton.addEventListener('click', () => {
      removeCard(cardElement);
    });
  
    return cardElement;
  }
  
  // @todo: Функция удаления карточки
  function removeCard(cardElement) {
    cardElement.remove(cardElement);
  }
  
  
  // @todo: Вывести карточки на страницу
  function renderCards(cards) {
    cards.forEach(cardData => {
        const cardElement = createCard(cardData);
        placesList.append(cardElement);
    });
  }
  renderCards(initialCards);